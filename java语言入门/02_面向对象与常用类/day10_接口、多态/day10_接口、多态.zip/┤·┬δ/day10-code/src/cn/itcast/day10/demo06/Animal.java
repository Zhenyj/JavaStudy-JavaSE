package cn.itcast.day10.demo06;

public abstract class Animal {

    public abstract void eat();

}
