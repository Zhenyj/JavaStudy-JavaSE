package cn.itcast.day10.demo04;

public class Zi extends Fu {

    @Override
    public void method() {
        System.out.println("子类方法");
    }
}
